<?php
error_reporting(0);
// $conn =mysql_connect('localhost','root',"", 'hms')or die(mysql_error($db_connect());
mysql_select_db("hms") or die(mysql_error($db_connect));

$conn = mysql_connect('localhost','root','','hms') or die(mysqli_error());
?>
